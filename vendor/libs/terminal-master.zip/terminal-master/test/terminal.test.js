QUnit.module('Terminal');

QUnit.test('new Terminal()', function () {
	ok(new Terminal(), 'new Terminal()');
});
